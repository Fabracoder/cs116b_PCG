 

 
			var radius = 1371;
 
 
			var MARGIN = 0;
			var SCREEN_HEIGHT = window.innerHeight - MARGIN * 2;
			var SCREEN_WIDTH  = window.innerWidth;

			var container, stats;
			var camera, controls, scene, sceneCube, renderer;
			var buildings=[];
			var dirLight, pointLight, ambientLight;
 

			var clock = new THREE.Clock();

			init();
			animate();

			function init() {

				container = document.createElement( 'div' );
				document.body.appendChild( container );

				camera = new THREE.PerspectiveCamera( 25, SCREEN_WIDTH / SCREEN_HEIGHT, 50, 1e7 );
				camera.position.z = 1000 * 5;
                camera.position.y = 100 * 5;
                

				scene = new THREE.Scene();
				scene.fog = new THREE.FogExp2( 0x0000f0, 0.00000025 );

				controls = new THREE.FlyControls( camera );

				controls.movementSpeed = 1000;
				controls.domElement = container;
				controls.rollSpeed = Math.PI / 24;
				controls.autoForward = false;
				controls.dragToLook = false;

				dirLight = new THREE.DirectionalLight( 0xcccccc );
				dirLight.position.set( 0, 1, 1 ).normalize();
				scene.add( dirLight );

                ambientLight = new THREE.AmbientLight( 0x515151 ); 
				scene.add( ambientLight);

				var materialNormalMap = new THREE.MeshPhongMaterial( {
				
					specular: 0x333333,
					shininess: 15,
					map: THREE.ImageUtils.loadTexture( "Resources/final_textures/ea2048.jpg" ),
					specularMap: THREE.ImageUtils.loadTexture( "Resources/final_textures/ea_specular_2048.jpg" ),
					normalMap: THREE.ImageUtils.loadTexture( "Resources/final_textures/ea_normal_2048.jpg" ),
					normalScale: new THREE.Vector2( 0.85, 0.85 )
				
				} );

				var materialQ = new THREE.MeshPhongMaterial( {
				
					specular: 0x333333,
					shininess: 15,
					map: THREE.ImageUtils.loadTexture( "Resources/final_textures/greyb.jpg" ),
					specularMap: THREE.ImageUtils.loadTexture( "Resources/final_textures/ea_specular_2048.jpg" ) 				} );                
                   
                var materialX = new THREE.MeshPhongMaterial({
                    // light
                    specular: '#aabbcc',
                    // intermediate
                    color: '#ccccdd',
                    // dark
                    emissive: '#a0a063',
                    shininess: 100 
                    });
 
                var floorGeometry = new THREE.BoxGeometry(100000,100,100000);
                var floorMesh = new THREE.Mesh(floorGeometry,materialNormalMap); 
                scene.add (floorMesh);
  
  // add random buildings
                 
                
                for( i = 0; i < 200; i++ )
                {
                    var buildingPos =  new THREE.Vector3();
                    buildingPos.x= Math.random()*10000;
                    buildingPos.y= 100;
                    buildingPos.z= Math.random()*10000;
                                     
                    var bsize =  new THREE.Vector3();
                    bsize.x= Math.random()*460+4;
                    bsize.z= Math.random()*460+4;
                    bsize.y= Math.random()*1000;
                    
                    var geomMesh = new THREE.Mesh(new THREE.BoxGeometry(bsize.x,bsize.y,bsize.z),materialQ);
                    geomMesh.translateX(buildingPos.x);
                    geomMesh.translateY(buildingPos.y);
                    geomMesh.translateZ(buildingPos.z);
                    var building = {
                          'pos': buildingPos,
                          'size':  bsize ,
                          'mesh': geomMesh
                        };
                    buildings.push(building);
console.log(building);
                    scene.add(building.mesh);
                }
                
				// stars
                {
				var i, r = radius, starsGeometry = [ new THREE.Geometry(), new THREE.Geometry() ];

				for ( i = 0; i < 250; i ++ ) {

					var vertex = new THREE.Vector3();
					vertex.x = Math.random() * 2 - 1;
					vertex.y = Math.random() * 2 - 1;
					vertex.z = Math.random() * 2 - 1;
					vertex.multiplyScalar( r );

					starsGeometry[ 0 ].vertices.push( vertex );

				}

				for ( i = 0; i < 1500; i ++ ) {

					var vertex = new THREE.Vector3();
					vertex.x = Math.random() * 2 - 1;
					vertex.y = Math.random() * 2 - 1;
					vertex.z = Math.random() * 2 - 1;
					vertex.multiplyScalar( r );

					starsGeometry[ 1 ].vertices.push( vertex );

				}

				var stars;
				var starsMaterials = [
					new THREE.PointCloudMaterial( { color: 0x555555, size: 2, sizeAttenuation: false } ),
					new THREE.PointCloudMaterial( { color: 0x555555, size: 1, sizeAttenuation: false } ),
					new THREE.PointCloudMaterial( { color: 0x333333, size: 2, sizeAttenuation: false } ),
					new THREE.PointCloudMaterial( { color: 0x3a3a3a, size: 1, sizeAttenuation: false } ),
					new THREE.PointCloudMaterial( { color: 0x1a1a1a, size: 2, sizeAttenuation: false } ),
					new THREE.PointCloudMaterial( { color: 0x1a1a1a, size: 1, sizeAttenuation: false } )
				];

				for ( i = 10; i < 30; i ++ ) {

					stars = new THREE.PointCloud( starsGeometry[ i % 2 ], starsMaterials[ i % 6 ] );

					stars.rotation.x = Math.random() * 6;
					stars.rotation.y = Math.random() * 6;
					stars.rotation.z = Math.random() * 6;

					s = i * 10;
					stars.scale.set( s, s, s );

					stars.matrixAutoUpdate = false;
					stars.updateMatrix();

					scene.add( stars );

				}
}
				renderer = new THREE.WebGLRenderer();
				renderer.setPixelRatio( window.devicePixelRatio );
				renderer.setSize( SCREEN_WIDTH, SCREEN_HEIGHT );
   

                renderer.render( scene, camera );
				container.appendChild( renderer.domElement );

				stats = new Stats();
				stats.domElement.style.position = 'absolute';
				stats.domElement.style.top = '0px';
				stats.domElement.style.zIndex = 100;
				container.appendChild( stats.domElement );

				window.addEventListener( 'resize', onWindowResize, false );

 
			};

			function onWindowResize( event ) {

				SCREEN_HEIGHT = window.innerHeight;
				SCREEN_WIDTH  = window.innerWidth;

				renderer.setSize( SCREEN_WIDTH, SCREEN_HEIGHT );

				camera.aspect = SCREEN_WIDTH / SCREEN_HEIGHT;
				camera.updateProjectionMatrix();

				composer.reset();

			};

			function animate() {

				requestAnimationFrame( animate );
				render();
				stats.update();

			};

			function render() {
 
				var delta = clock.getDelta();
    
				controls.movementSpeed = 10000*(delta);
				controls.update( delta );

//				renderer.clear();
                renderer.render( scene, camera );

			};
 